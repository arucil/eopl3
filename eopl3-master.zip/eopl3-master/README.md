This is all the code from the book Essentials of Programming
Languages, 3rd edition, by Friedman and Wand.

The code dates from 2009.  It has now been updated and should run
right out of the box on Racket version 5.3.6.

To run any of the languages, select "Choose language from source", and run top.scm in any of the language directories (chapterN/*-lang).

The file test-all.rkt will go through and test all of the testable
languages. 

If you are feeling adventurous, you can try to adapt the code
base to use the rackunit testing framework instead of the kludgy one I
threw together for the book. 

Enjoy!

--Mitch


